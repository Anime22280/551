package com.github.ybq.android.loading;

/**
 * Created by ybq.
 */
public interface Colors {
    int[] colors = new int[]{
            0XFFD55400,
            0XFF2B3E51,
            0XFF00BD9C,
            0XFF227FBB,
            0XFF7F8C8D,
            0XFFFFCC5C,
            0XFFD55400,
            0XFF1AAF5D,
    };
}
